/*
 * Copyright (C) 2000, 2001, 2002 Björn Englund <d4bjorn@dtek.chalmers.se>,
 *                                Håkan Hjort <d95hjort@dtek.chalmers.se>
 *
 * This file is part of libdvdread.
 *
 * libdvdread is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * libdvdread is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with libdvdread; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef LIBDVDREAD_IFO_READ_H
#define LIBDVDREAD_IFO_READ_H

#include <dvdread/ifo_types.h>
#include <dvdread/attributes.h>
#include <dvdread/dvd_reader.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * handle = ifoOpen(dvd, title);
 *
 * Opens an IFO and reads in all the data for the IFO file corresponding to the
 * given title.  If title 0 is given, the video manager IFO file is read.
 * Returns a handle to a completely parsed structure.
 */
DVDREAD_API ifo_handle_t *ifoOpen(dvd_reader_t *, int );

/**
 * handle = ifoOpenVMGI(dvd);
 *
 * Opens an IFO and reads in _only_ the vmgi_mat data.  This call can be used
 * together with the calls below to read in each segment of the IFO file on
 * demand. If the dvd_reader opened an DVD-Audio Disc, this will open the AMGI
 */
DVDREAD_API ifo_handle_v_t *ifoOpenVMGI(dvd_reader_t *);
DVDREAD_API ifo_handle_t* ifoOpenXMGI(dvd_reader_t*);

/**
 * handle = ifoOpenVTSI(dvd, title);
 *
 * Opens an IFO and reads in _only_ the vtsi_mat data.  This call can be used
 * together with the calls below to read in each segment of the IFO file on
 * demand. If the dvd_reader opened an DVD-Audio Disc, this will open the ATSI
 */
DVDREAD_API ifo_handle_v_t *ifoOpenVTSI(dvd_reader_t *, int);
DVDREAD_API ifo_handle_t* ifoOpenXTSI(dvd_reader_t*, int);

/**
 * ifoClose(ifofile);
 * Cleans up the IFO information.  This will free all data allocated for the
 * substructures.
 */
DVDREAD_API void ifoClose(ifo_handle_t *);

void ifoCloseV(ifo_handle_v_t*);

void ifoAddRef(ifo_handle_t *);
void ifoAddRefV(ifo_handle_v_t*);

/**
 * The following functions are for reading only part of the VMGI/VTSI files.
 * Returns 1 if the data was successfully read and 0 on error.
 */

/**
 * okay = ifoRead_PLT_MAIT(ifofile);
 *
 * Read in the Parental Management Information table, filling the
 * ifofile->ptl_mait structure and its substructures.  This data is only
 * located in the video manager information file.  This fills the
 * ifofile->ptl_mait structure and all its substructures.
 */
DVDREAD_API int ifoRead_PTL_MAIT(ifo_handle_v_t *);

/**
 * okay = ifoRead_VTS_ATRT(ifofile);
 *
 * Read in the attribute table for the main menu vob, filling the
 * ifofile->vts_atrt structure and its substructures.  Only located in the
 * video manager information file.  This fills in the ifofile->vts_atrt
 * structure and all its substructures.
 */
DVDREAD_API int ifoRead_VTS_ATRT(ifo_handle_v_t *);

/**
 * okay = ifoRead_TT_SRPT(ifofile);
 *
 * Reads the title info for the main menu, filling the ifofile->tt_srpt
 * structure and its substructures.  This data is only located in the video
 * manager information file.  This structure is mandatory in the IFO file.
 */
DVDREAD_API int ifoRead_TT_SRPT(ifo_handle_v_t *);

/**
 * okay = ifoRead_VTS_PTT_SRPT(ifofile);
 *
 * Reads in the part of title search pointer table, filling the
 * ifofile->vts_ptt_srpt structure and its substructures.  This data is only
 * located in the video title set information file.  This structure is
 * mandatory, and must be included in the VTSI file.
 */
DVDREAD_API int ifoRead_VTS_PTT_SRPT(ifo_handle_v_t *);

/**
 * okay = ifoRead_FP_PGC(ifofile);
 *
 * Reads in the first play program chain data, filling the
 * ifofile->first_play_pgc structure.  This data is only located in the video
 * manager information file (VMGI).  This structure is optional.
 */
DVDREAD_API int ifoRead_FP_PGC(ifo_handle_v_t *);

/**
 * okay = ifoRead_PGCIT(ifofile);
 *
 * Reads in the program chain information table for the video title set.  Fills
 * in the ifofile->vts_pgcit structure and its substructures, which includes
 * the data for each program chain in the set.  This data is only located in
 * the video title set information file.  This structure is mandatory, and must
 * be included in the VTSI file.
 */
DVDREAD_API int ifoRead_PGCIT(ifo_handle_v_t *);

/**
 * okay = ifoRead_PGCI_UT(ifofile);
 *
 * Reads in the menu PGCI unit table for the menu VOB.  For the video manager,
 * this corresponds to the VIDEO_TS.VOB file, and for each title set, this
 * corresponds to the VTS_XX_0.VOB file.  This data is located in both the
 * video manager and video title set information files.  For VMGI files, this
 * fills the ifofile->vmgi_pgci_ut structure and all its substructures.  For
 * VTSI files, this fills the ifofile->vtsm_pgci_ut structure.
 */
DVDREAD_API int ifoRead_PGCI_UT(ifo_handle_v_t *);

/**
 * okay = ifoRead_VTS_TMAPT(ifofile);
 *
 * Reads in the VTS Time Map Table, this data is only located in the video
 * title set information file.  This fills the ifofile->vts_tmapt structure
 * and all its substructures.  When present enables VOBU level time-based
 * seeking for One_Sequential_PGC_Titles.
 */
DVDREAD_API int ifoRead_VTS_TMAPT(ifo_handle_v_t *);

/**
 * okay = ifoRead_C_ADT(ifofile);
 *
 * Reads in the cell address table for the menu VOB.  For the video manager,
 * this corresponds to the VIDEO_TS.VOB file, and for each title set, this
 * corresponds to the VTS_XX_0.VOB file.  This data is located in both the
 * video manager and video title set information files.  For VMGI files, this
 * fills the ifofile->vmgm_c_adt structure and all its substructures.  For VTSI
 * files, this fills the ifofile->vtsm_c_adt structure.
 */
DVDREAD_API int ifoRead_C_ADT(ifo_handle_v_t *);

/**
 * okay = ifoRead_TITLE_C_ADT(ifofile);
 *
 * Reads in the cell address table for the video title set corresponding to
 * this IFO file.  This data is only located in the video title set information
 * file.  This structure is mandatory, and must be included in the VTSI file.
 * This call fills the ifofile->vts_c_adt structure and its substructures.
 */
DVDREAD_API int ifoRead_TITLE_C_ADT(ifo_handle_v_t *);

/**
 * okay = ifoRead_VOBU_ADMAP(ifofile);
 *
 * Reads in the VOBU address map for the menu VOB.  For the video manager, this
 * corresponds to the VIDEO_TS.VOB file, and for each title set, this
 * corresponds to the VTS_XX_0.VOB file.  This data is located in both the
 * video manager and video title set information files.  For VMGI files, this
 * fills the ifofile->vmgm_vobu_admap structure and all its substructures.  For
 * VTSI files, this fills the ifofile->vtsm_vobu_admap structure.
 */
DVDREAD_API int ifoRead_VOBU_ADMAP(ifo_handle_v_t *);

/**
 * okay = ifoRead_TITLE_VOBU_ADMAP(ifofile);
 *
 * Reads in the VOBU address map for the associated video title set.  This data
 * is only located in the video title set information file.  This structure is
 * mandatory, and must be included in the VTSI file.  Fills the
 * ifofile->vts_vobu_admap structure and its substructures.
 */
DVDREAD_API int ifoRead_TITLE_VOBU_ADMAP(ifo_handle_v_t *);

/**
 * okay = ifoRead_TXTDT_MGI(ifofile);
 *
 * Reads in the text data strings for the DVD.  Fills the ifofile->txtdt_mgi
 * structure and all its substructures.  This data is only located in the video
 * manager information file.  This structure is mandatory, and must be included
 * in the VMGI file.
 */
DVDREAD_API int ifoRead_TXTDT_MGI(ifo_handle_v_t *);

/**
 * okay = ifoRead_TT(ifofile);
 *
 * Reads the Title Track Table in ATS IFO's.
 * This structure. This structure is mandatory, and must be included
 * in the AMGI file.
 */
DVDREAD_API int ifoRead_TT(ifo_handle_a_t *);

/**
 * okay = ifoRead_TIF(ifofile);
 *
 * Reads either table in AUDIO_TS.IFO based on the sector offset given,
 * either 1,2. The first table being one with video titles, the second one
 * without. This structure. This structure is mandatory, and must be included
 * in the AMGI file.
 */
DVDREAD_API int ifoRead_TIF(ifo_handle_a_t *, int);

/**
 * The following functions are used for freeing parsed sections of the
 * ifo_handle_t structure and the allocated substructures.  The free calls
 * below are safe:  they will not mind if you attempt to free part of an IFO
 * file which was not read in or which does not exist.
 */
DVDREAD_API void ifoFree_PTL_MAIT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_VTS_ATRT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_TT_SRPT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_VTS_PTT_SRPT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_FP_PGC(ifo_handle_v_t *);
DVDREAD_API void ifoFree_PGCIT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_PGCI_UT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_VTS_TMAPT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_C_ADT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_TITLE_C_ADT(ifo_handle_v_t *);
DVDREAD_API void ifoFree_VOBU_ADMAP(ifo_handle_v_t *);
DVDREAD_API void ifoFree_TITLE_VOBU_ADMAP(ifo_handle_v_t *);
DVDREAD_API void ifoFree_TXTDT_MGI(ifo_handle_v_t *);
DVDREAD_API void ifoFree_TT(ifo_handle_a_t *);

#ifdef __cplusplus
};
#endif
#endif /* LIBDVDREAD_IFO_READ_H */
